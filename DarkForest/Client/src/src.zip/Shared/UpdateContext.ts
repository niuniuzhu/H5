namespace Shared {
	export class UpdateContext {
		public deltaTime: number = 0;
		public time: number = 0;
		public frame: number = 0;

		constructor() {
		}
	}
}