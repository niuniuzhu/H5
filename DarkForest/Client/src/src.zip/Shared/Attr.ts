namespace Shared {
	export enum Attr {
		Undefine = 0,

		Id = 2,
		Name = 3,
		Model = 4,
		Bounds = 5,
		Position = 6,
		Direction = 7,

		Uid = 50,
		Team = 51,
	}
}